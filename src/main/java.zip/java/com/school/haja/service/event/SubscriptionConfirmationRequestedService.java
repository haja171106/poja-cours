package com.school.haja.service.event;

import com.school.haja.endpoint.event.model.SubscriptionConfirmationRequested;
import com.school.haja.mail.Attachment;
import com.school.haja.mail.Email;
import com.school.haja.mail.Mailer;
import jakarta.mail.internet.InternetAddress;
import java.util.List;
import java.util.function.Consumer;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class SubscriptionConfirmationRequestedService
        implements Consumer<SubscriptionConfirmationRequested> {

    private final Mailer mailer;

    @SneakyThrows
    @Override
    public void accept(SubscriptionConfirmationRequested event) {
        InternetAddress recipient = new InternetAddress(event.getTo());

        byte[] pdfBytes = SubscriptionConfirmationPdfGenerator.generate(event);
        Attachment attachment =
                new Attachment(
                        "confirmation-inscription.pdf", "application/pdf", pdfBytes);

        String body =
                "Bonjour "
                        + event.getUserFirstName()
                        + ",\n\nVotre inscription au cours \""
                        + event.getCourseTitle()
                        + "\" a bien ete enregistree avec succes.\n\nVous trouverez le recapitulatif en pièce jointe.\n\nA bientot !";

        mailer.accept(
                new Email(
                        recipient,
                        List.of(),
                        List.of(),
                        "Confirmation d'inscription",
                        body,
                        List.of(attachment)));
    }
}