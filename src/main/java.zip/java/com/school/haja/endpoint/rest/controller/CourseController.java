package com.school.haja.endpoint.rest.controller;

import com.school.haja.endpoint.rest.controller.dto.CreateCourseRequest;
import com.school.haja.repository.model.JCourse;
import com.school.haja.service.CourseService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/courses")
@AllArgsConstructor
public class CourseController {

    private final CourseService courseService;

    @PostMapping
    public ResponseEntity<JCourse> createCourse(@RequestBody CreateCourseRequest request) {
        var created = courseService.createCourse(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }
}